# Hyttebooking – installation af mellemvejsløsningen

## 1. Arkitektur

Den nye løsning er:

CMS → iframe → `booking.ditdomæne.dk`
→ Cloudflare Pages (HTML/CSS/JS)
→ `/api/booking` (Cloudflare Pages Function)
→ Google Apps Script
→ Google Sheets + Google Calendar + MailApp

Google Sheets er fortsat administrationsfladen. Google Calendar er fortsat sandhedskilden for godkendte og interne bookinger.

## 2. Hvad genbruges?

Behold de senest opdaterede:
- `Code.gs`
- `BookingService.gs`
- `AdminService.gs`

Erstat:
- `WebApp.gs` med `apps-script/WebApp.gs` fra pakken.

Apps Scripts gamle `Index.html` bruges ikke længere. Vent med at slette den, til den nye løsning er testet.

## 3. Opret API_SECRET i Apps Script

1. Åbn Google Sheet.
2. Vælg **Udvidelser → Apps Script**.
3. Klik **Projektindstillinger**.
4. Find **Scriptegenskaber / Script properties**.
5. Tilføj:
   - Navn: `API_SECRET`
   - Værdi: en lang tilfældig streng på mindst 32 tegn.
6. Gem.
7. Opbevar værdien sikkert. Den samme værdi skal ind i Cloudflare.

API_SECRET må aldrig lægges i `public/app.js`.

## 4. Genimplementer Apps Script

1. Vælg **Implementer → Administrer implementeringer**.
2. Redigér din webapp-implementering.
3. Vælg **Ny version**.
4. Kør som: **Dig selv**.
5. Sørg for, at webappen kan tilgås uden Google-login af Cloudflare-proxyen (typisk adgang som **Alle/Anyone**).
6. Implementér.
7. Kopiér webappens `/exec`-URL.

Eksempel:
`https://script.google.com/macros/s/XXXXXXXX/exec`

URL'en skal kun gemmes server-side i Cloudflare.

## 5. Opret et GitHub repository

Opret fx repository:
`hyttebooking`

Upload indholdet af denne pakke, så roden ser sådan ud:

```text
hyttebooking/
├─ public/
│  ├─ index.html
│  ├─ styles.css
│  ├─ app.js
│  └─ _routes.json
├─ functions/
│  └─ api/
│     └─ booking.js
└─ apps-script/
   └─ WebApp.gs
```

`apps-script`-mappen bliver blot dokumentation/backup på GitHub. Den bliver ikke offentliggjort, fordi Cloudflare build output sættes til `public`.

## 6. Opret Cloudflare Pages

1. Log ind på Cloudflare.
2. Gå til **Workers & Pages**.
3. Opret et Pages-projekt fra Git.
4. Forbind GitHub og vælg `hyttebooking`.
5. Brug:
   - Framework preset: **None**
   - Build command: `exit 0`
   - Build output directory: `public`
6. Deploy.

Projektet får fx:
`https://hyttebooking.pages.dev`

Pages Functions bruger filbaseret routing. Derfor bliver:
`functions/api/booking.js`
automatisk til:
`/api/booking`

## 7. Opret miljøvariabler i Cloudflare

På Pages-projektets Settings skal du oprette:

### APPS_SCRIPT_URL
Værdi:
Apps Script `/exec`-URL'en.

### API_SECRET
Værdi:
Præcis samme hemmelige streng som Script Property `API_SECRET` i Apps Script.

Sæt dem mindst for **Production**. Hvis du vil bruge preview deployments til test, tilføj dem også dér.

Lav derefter en ny deployment.

## 8. Første test på pages.dev

Åbn:
`https://hyttebooking.pages.dev`

Test:

1. Hyttens navn vises.
2. Kalenderen indlæses.
3. Du kan bladre frem.
4. Google Calendar-bookinger vises som helt/delvist optaget.
5. Vælg en ledig dato.
6. Standardperioder vises.
7. Priser er korrekte.
8. Send en testbooking med egen mail.
9. Kontrollér `AFVENTER` i Google Sheet.
10. Kontrollér mails.
11. Kontrollér at den afventende periode blokerer.
12. Godkend i Google Sheet.
13. Kontrollér Google Calendar.
14. Test CUSTOM.
15. Test afvisning.
16. Test annullering.

## 9. Eget domæne

Jeg anbefaler:
`booking.ditdomæne.dk`

I Cloudflare Pages:
1. Åbn projektet.
2. Vælg **Custom domains**.
3. Vælg **Set up a domain**.
4. Angiv subdomænet.
5. Følg DNS-guiden.

## 10. Integrér i CMS

Når subdomænet virker:

```html
<iframe
  src="https://booking.ditdomæne.dk/"
  title="Hyttebooking"
  width="100%"
  height="1200"
  style="border:0;width:100%;"
  loading="lazy">
</iframe>
```

Tilpas højden efter CMS-layoutet.

## 11. Interne bookinger

Interne bookinger kræver ingen særlig frontend-funktion.

Opret dem direkte i den private Google Calendar, fx:
`INTERN – Lederweekend`

Frontend får kun optaget-status og viser ikke eventtitlen.

## 12. Fremtidige opdateringer

### Design/frontend
Ret:
- `public/index.html`
- `public/styles.css`
- `public/app.js`

Commit/push → Cloudflare deployer automatisk.

### Bookinglogik/backend
Ret Apps Script:
- `BookingService.gs`
- `AdminService.gs`
- `WebApp.gs`
- evt. `Code.gs`

Opret derefter en ny Apps Script deployment-version.

### Priser og sæsoner
Ret direkte i Google Sheets.
Ingen kode-deployment er nødvendig.

## 13. Hvorfor proxyen er med

Direkte browser-`fetch()` fra et andet domæne til Apps Script kan give CORS/preflight-problemer, og Apps Script giver begrænset kontrol over disse HTTP-responser.

Her kalder browseren kun:
`https://booking.ditdomæne.dk/api/booking`

Det er same-origin. Cloudflare-funktionen kalder derefter Apps Script server-to-server og tilføjer den hemmelige API-nøgle.

Det gør Apps Script-URL og API_SECRET usynlige for den almindelige browserkode.

## 14. Sikkerhed før produktion

- Google Calendar skal være privat.
- `API_SECRET` skal kun ligge i Apps Script Script Properties og Cloudflare Environment Variables.
- Brug aldrig API_SECRET i public-filer.
- Behold server-side prisberegning og `LockService`.
- Behold privacy-sikker Calendar-titel `BOOKET – <booking-ID>`.
- Honeypot er inkluderet som basalt spamfilter.
- Hvis der senere kommer spam, er Cloudflare Turnstile/rate limiting næste trin.
