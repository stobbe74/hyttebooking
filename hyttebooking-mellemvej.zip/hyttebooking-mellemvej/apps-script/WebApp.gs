/**
 * WebApp.gs – API til ekstern frontend.
 *
 * ERSTATTER den tidligere WebApp.gs, der serverede Index.html.
 * Frontend kalder Cloudflare /api/booking, som videresender
 * forespørgslen til denne Apps Script-webapp.
 */

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) {
      throw new Error('Forespørgslen indeholder ingen data.');
    }

    const request = JSON.parse(e.postData.contents);
    validateApiSecret_(request.apiSecret);

    const action = String(request.action || '').trim();
    let data;

    switch (action) {
      case 'initial':
        data = getInitialData();
        data.bookingHorizonYears = BOOKING_HORIZON_YEARS;
        break;

      case 'calendarMonth':
        data = getCalendarMonth(request.year, request.month);
        break;

      case 'bookingOptions':
        data = getBookingOptions(request.dateString);
        break;

      case 'checkAvailability':
        data = checkAvailability(request.startValue, request.endValue);
        break;

      case 'submitBooking':
        data = submitBookingRequest(request.data);
        break;

      default:
        throw new Error('Ukendt API-handling.');
    }

    return jsonOutput_({ ok: true, data: data });

  } catch (error) {
    console.error('API-fejl:', error);
    return jsonOutput_({
      ok: false,
      error: error && error.message
        ? error.message
        : 'Der opstod en ukendt fejl.'
    });
  }
}


/**
 * Den hemmelige nøgle ligger som Script Property:
 * API_SECRET
 */
function validateApiSecret_(suppliedSecret) {
  const expectedSecret =
    PropertiesService
      .getScriptProperties()
      .getProperty('API_SECRET');

  if (!expectedSecret) {
    throw new Error(
      'API_SECRET er ikke konfigureret i Apps Script.'
    );
  }

  if (
    !suppliedSecret ||
    String(suppliedSecret) !== String(expectedSecret)
  ) {
    throw new Error('Adgang til API blev afvist.');
  }
}


function jsonOutput_(value) {
  return ContentService
    .createTextOutput(JSON.stringify(value))
    .setMimeType(ContentService.MimeType.JSON);
}


/* =========================================================
   INITIAL DATA
   ========================================================= */

function getInitialData() {
  const settings = getSettings_();

  return {
    hutName: settings.HYTTE_NAVN || 'Hytten',
    cleaningPrice: Number(settings.SLUTRENGORING || 745),
    deposit: Number(settings.DEPOSITUM || 1000),
    includedElectricity: Number(settings.INKLUDERET_EL_KWH || 30),
    extraElectricityPrice: Number(settings.EKSTRA_EL_PRIS || 3)
  };
}


/* =========================================================
   BOOKINGMULIGHEDER
   ========================================================= */

function getBookingOptions(dateString) {
  if (!dateString) {
    throw new Error('Der mangler en ankomstdato.');
  }

  const startDate = parseDateOnly_(dateString);

  if (startDate < startOfToday_()) {
    throw new Error('Der kan ikke bookes i fortiden.');
  }

  validateBookingHorizon_(startDate);
  return buildBookingOptions_(startDate);
}


/* =========================================================
   LEDIGHEDSKONTROL
   ========================================================= */

function checkAvailability(startValue, endValue) {
  if (!startValue || !endValue) {
    throw new Error('Ankomst og afrejse mangler.');
  }

  const start = parseLocalDateTime_(startValue);
  const end = parseLocalDateTime_(endValue);

  if (end <= start) {
    throw new Error('Afrejse skal være efter ankomst.');
  }

  if (start < new Date()) {
    throw new Error('Der kan ikke bookes i fortiden.');
  }

  validateBookingHorizon_(start);
  validateBookingHorizon_(end);

  return {
    available: isPeriodAvailable_(start, end)
  };
}


/* =========================================================
   MODTAG BOOKINGFORESPØRGSEL
   ========================================================= */

function submitBookingRequest(data) {
  validateBookingRequest_(data);

  let savedBooking = null;
  const lock = LockService.getScriptLock();

  try {
    lock.waitLock(15000);

    const canonical = buildCanonicalBooking_(data);

    if (!isPeriodAvailable_(canonical.start, canonical.end)) {
      throw new Error(
        'Perioden er ikke længere ledig. ' +
        'En anden forespørgsel kan være blevet registreret.'
      );
    }

    const settings = getSettings_();
    const cleaningSelected = Boolean(data.cleaning);

    const cleaningPrice = cleaningSelected
      ? Number(settings.SLUTRENGORING || 0)
      : 0;

    const deposit = Number(settings.DEPOSITUM || 0);

    const total = canonical.code === 'CUSTOM'
      ? ''
      : Number(canonical.price) + cleaningPrice + deposit;

    const bookingId = createSecureBookingId_();
    const sheet = getBookingSheet_(CONFIG.SHEETS.BOOKINGS);

    sheet.appendRow([
      bookingId,
      new Date(),
      'AFVENTER',
      canonical.code,
      canonical.start,
      canonical.end,
      sanitise_(data.name),
      sanitise_(data.email),
      sanitise_(data.phone),
      Number(data.people),
      sanitise_(data.organisation || ''),
      sanitise_(data.comment || ''),
      canonical.code === 'CUSTOM' ? '' : canonical.price,
      cleaningPrice,
      deposit,
      total,
      ''
    ]);

    SpreadsheetApp.flush();

    savedBooking = {
      bookingId: bookingId,
      bookingType: canonical.code,
      bookingName: canonical.name,
      start: canonical.start,
      end: canonical.end,
      name: sanitise_(data.name),
      email: sanitise_(data.email),
      phone: sanitise_(data.phone),
      people: Number(data.people),
      organisation: sanitise_(data.organisation || ''),
      comment: sanitise_(data.comment || ''),
      basePrice: canonical.code === 'CUSTOM' ? '' : canonical.price,
      cleaningPrice: cleaningPrice,
      deposit: deposit,
      total: total
    };

  } finally {
    if (lock.hasLock()) {
      lock.releaseLock();
    }
  }

  if (savedBooking) {
    try {
      sendBookingEmails_(savedBooking);
    } catch (emailError) {
      console.error(
        'Booking ' + savedBooking.bookingId +
        ' blev gemt, men e-mail kunne ikke sendes:',
        emailError
      );
    }

    return {
      success: true,
      bookingId: savedBooking.bookingId
    };
  }

  throw new Error('Bookingforespørgslen kunne ikke registreres.');
}


/* =========================================================
   MÅNEDSKALENDER
   ========================================================= */

function getCalendarMonth(year, month) {
  year = Number(year);
  month = Number(month);

  if (
    !Number.isInteger(year) ||
    !Number.isInteger(month) ||
    month < 0 ||
    month > 11
  ) {
    throw new Error('Ugyldig måned.');
  }

  const firstDay = new Date(year, month, 1, 0, 0, 0, 0);
  const nextMonth = new Date(year, month + 1, 1, 0, 0, 0, 0);
  const today = new Date();

  const earliestMonth = new Date(
    today.getFullYear(),
    today.getMonth(),
    1, 0, 0, 0, 0
  );

  const latestMonth = new Date(
    today.getFullYear() + BOOKING_HORIZON_YEARS,
    today.getMonth(),
    1, 0, 0, 0, 0
  );

  if (firstDay < earliestMonth) {
    throw new Error('Der kan ikke vises måneder i fortiden.');
  }

  if (firstDay > latestMonth) {
    throw new Error(
      'Der kan maksimalt vises ' +
      BOOKING_HORIZON_YEARS +
      ' år frem.'
    );
  }

  const unavailable = getUnavailablePeriods_()
    .map(period => ({
      start: new Date(period.start),
      end: new Date(period.end)
    }))
    .filter(period =>
      !isNaN(period.start.getTime()) &&
      !isNaN(period.end.getTime()) &&
      period.start < nextMonth &&
      period.end > firstDay
    );

  const numberOfDays =
    new Date(year, month + 1, 0).getDate();

  const days = [];

  for (let day = 1; day <= numberOfDays; day++) {
    const dayStart =
      new Date(year, month, day, 0, 0, 0, 0);

    const dayEnd =
      new Date(year, month, day + 1, 0, 0, 0, 0);

    const intervals = [];

    unavailable.forEach(period => {
      const overlapStart = Math.max(
        dayStart.getTime(),
        period.start.getTime()
      );

      const overlapEnd = Math.min(
        dayEnd.getTime(),
        period.end.getTime()
      );

      if (overlapStart < overlapEnd) {
        intervals.push({
          start: overlapStart,
          end: overlapEnd
        });
      }
    });

    intervals.sort((a, b) => a.start - b.start);

    const merged = [];

    intervals.forEach(interval => {
      const last = merged[merged.length - 1];

      if (!last || interval.start > last.end) {
        merged.push({
          start: interval.start,
          end: interval.end
        });
      } else {
        last.end = Math.max(last.end, interval.end);
      }
    });

    const occupiedMilliseconds =
      merged.reduce(
        (total, interval) =>
          total + (interval.end - interval.start),
        0
      );

    const wholeDay =
      dayEnd.getTime() - dayStart.getTime();

    let state = 'AVAILABLE';

    if (occupiedMilliseconds >= wholeDay) {
      state = 'FULL';
    } else if (occupiedMilliseconds > 0) {
      state = 'PARTIAL';
    }

    days.push({
      day: day,
      date: Utilities.formatDate(
        dayStart,
        TIMEZONE,
        'yyyy-MM-dd'
      ),
      state: state
    });
  }

  return {
    year: year,
    month: month,
    days: days
  };
}
