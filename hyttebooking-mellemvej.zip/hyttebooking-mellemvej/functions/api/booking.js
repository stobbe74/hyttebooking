export async function onRequestPost(context) {
  const { request, env } = context;

  if (!env.APPS_SCRIPT_URL || !env.API_SECRET) {
    return json({ ok: false, error: 'Serverkonfigurationen mangler.' }, 500);
  }

  let input;
  try { input = await request.json(); }
  catch { return json({ ok: false, error: 'Ugyldig forespørgsel.' }, 400); }

  const allowed = new Set(['initial','calendarMonth','bookingOptions','checkAvailability','submitBooking']);
  if (!allowed.has(input.action)) {
    return json({ ok: false, error: 'Ukendt handling.' }, 400);
  }

  if (input.action === 'submitBooking' && input.data && String(input.data.website || '').trim()) {
    return json({ ok: true, data: { success: true, bookingId: 'MODTAGET' } });
  }

  try {
    const upstream = await fetch(env.APPS_SCRIPT_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
      body: JSON.stringify({ ...input, apiSecret: env.API_SECRET }),
      redirect: 'follow'
    });

    const text = await upstream.text();
    let result;
    try { result = JSON.parse(text); }
    catch {
      console.error('Apps Script returned non-JSON:', text.slice(0, 500));
      return json({ ok: false, error: 'Backend returnerede et ugyldigt svar.' }, 502);
    }

    if (!result.ok) {
      return json({ ok: false, error: result.error || 'Backendfejl.' }, 400);
    }
    return json(result, 200);

  } catch (error) {
    console.error('Proxy error:', error);
    return json({ ok: false, error: 'Der kunne ikke oprettes forbindelse til bookingsystemet.' }, 502);
  }
}

export function onRequestGet() {
  return json({ ok: false, error: 'Method not allowed.' }, 405);
}

function json(value, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=UTF-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff'
    }
  });
}
