let initialData=null,selectedOption=null,selectedDate=null,currentYear=null,currentMonth=null,bookingHorizonYears=2;

const monthFormatter=new Intl.DateTimeFormat('da-DK',{month:'long',year:'numeric'});
const fullDateFormatter=new Intl.DateTimeFormat('da-DK',{weekday:'long',day:'numeric',month:'long',year:'numeric'});

document.addEventListener('DOMContentLoaded',initialise);

async function api(action,payload={}){
  const response=await fetch('/api/booking',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    cache:'no-store',
    body:JSON.stringify({action,...payload})
  });
  let result;
  try{result=await response.json();}catch{throw new Error('Bookingsystemet returnerede et ugyldigt svar.');}
  if(!response.ok||!result.ok)throw new Error(result.error||'Der opstod en fejl i bookingsystemet.');
  return result.data;
}

async function initialise(){
  const today=new Date();
  currentYear=today.getFullYear();
  currentMonth=today.getMonth();
  bindEvents();
  try{
    initialData=await api('initial');
    bookingHorizonYears=Number(initialData.bookingHorizonYears||2);
    document.getElementById('title').textContent='Booking af '+initialData.hutName;
    document.getElementById('cleaningPrice').textContent=' – '+formatMoney(initialData.cleaningPrice);
    updateNavigationButtons();
    await loadCalendar();
  }catch(error){showError(error);}
}

function bindEvents(){
  document.getElementById('previousMonthButton').addEventListener('click',previousMonth);
  document.getElementById('nextMonthButton').addEventListener('click',nextMonth);
  document.getElementById('customCheckButton').addEventListener('click',checkCustomAvailability);
  document.getElementById('cleaning').addEventListener('change',renderPriceSummary);
  document.getElementById('submitButton').addEventListener('click',submitBooking);
}

async function loadCalendar(){
  clearError();
  updateNavigationButtons();
  document.getElementById('calendar').innerHTML='<div class="loading" style="grid-column:1 / -1">Henter kalender...</div>';
  try{renderCalendar(await api('calendarMonth',{year:currentYear,month:currentMonth}));}
  catch(error){showError(error);}
}

function renderCalendar(data){
  const calendar=document.getElementById('calendar');
  calendar.innerHTML='';
  const monthDate=new Date(data.year,data.month,1);
  document.getElementById('monthTitle').textContent=monthFormatter.format(monthDate);

  let firstWeekday=monthDate.getDay();
  firstWeekday=firstWeekday===0?6:firstWeekday-1;
  for(let i=0;i<firstWeekday;i++){
    const empty=document.createElement('div');
    empty.className='calendar-day empty';
    calendar.appendChild(empty);
  }

  data.days.forEach(day=>{
    const div=document.createElement('div');
    div.className='calendar-day';
    div.dataset.date=day.date;
    const date=parseLocalDate(day.date);

    if(isPastDate(date))div.classList.add('past');
    if(day.state==='FULL')div.classList.add('full');
    if(day.state==='PARTIAL')div.classList.add('partial');
    if(selectedDate===day.date)div.classList.add('selected');

    const number=document.createElement('div');
    number.className='day-number';
    number.textContent=day.day;
    div.appendChild(number);

    const status=document.createElement('div');
    status.className='day-status';
    status.textContent=day.state==='FULL'?'Optaget':day.state==='PARTIAL'?'Delvist optaget':'Ledig';
    div.appendChild(status);

    if(!isPastDate(date)&&day.state!=='FULL'){
      div.addEventListener('click',()=>selectCalendarDate(day.date));
    }
    calendar.appendChild(div);
  });
  updateNavigationButtons();
}

function previousMonth(){
  const today=new Date();
  const earliest=new Date(today.getFullYear(),today.getMonth(),1);
  const candidate=new Date(currentYear,currentMonth-1,1);
  if(candidate<earliest)return;
  currentMonth--;
  if(currentMonth<0){currentMonth=11;currentYear--;}
  resetSelection();
  loadCalendar();
}

function nextMonth(){
  const latest=getLatestBookingMonth();
  const candidate=new Date(currentYear,currentMonth+1,1);
  if(candidate>latest)return;
  currentMonth++;
  if(currentMonth>11){currentMonth=0;currentYear++;}
  resetSelection();
  loadCalendar();
}

function getLatestBookingMonth(){
  const today=new Date();
  return new Date(today.getFullYear()+bookingHorizonYears,today.getMonth(),1);
}

function updateNavigationButtons(){
  if(currentYear===null||currentMonth===null)return;
  const today=new Date();
  const current=new Date(currentYear,currentMonth,1);
  const earliest=new Date(today.getFullYear(),today.getMonth(),1);
  const latest=getLatestBookingMonth();
  document.getElementById('previousMonthButton').disabled=current<=earliest;
  document.getElementById('nextMonthButton').disabled=current>=latest;
}

async function selectCalendarDate(dateString){
  clearError();
  selectedDate=dateString;
  selectedOption=null;
  hideElement('customCard');hideElement('formCard');hideElement('successCard');

  document.querySelectorAll('.calendar-day.selected').forEach(el=>el.classList.remove('selected'));
  const selectedCell=document.querySelector(`.calendar-day[data-date="${dateString}"]`);
  if(selectedCell)selectedCell.classList.add('selected');

  const date=parseLocalDate(dateString);
  document.getElementById('selectedDateTitle').textContent='Mulige lejeperioder – '+fullDateFormatter.format(date);
  showElement('optionsCard');
  document.getElementById('options').innerHTML='<div class="loading">Henter lejeperioder...</div>';
  try{renderOptions(await api('bookingOptions',{dateString}));}
  catch(error){showError(error);}
}

function renderOptions(result){
  const container=document.getElementById('options');
  container.innerHTML='';
  document.getElementById('seasonInfo').innerHTML=result.season==='SOMMER'
    ?'<div class="notice">Datoen ligger i sommerferieperioden. Sommerferiepriser gælder.</div>':'';

  result.options.forEach(option=>{
    const div=document.createElement('div');
    div.className='booking-option';
    if(!option.available)div.classList.add('unavailable');

    const name=document.createElement('div');
    name.className='option-name';name.textContent=option.name;div.appendChild(name);

    if(option.custom){
      const desc=document.createElement('div');desc.textContent=option.description;div.appendChild(desc);
      const price=document.createElement('div');price.className='option-price';price.textContent='Pris aftales';div.appendChild(price);
    }else{
      const period=document.createElement('div');period.textContent=option.formattedStart+' → '+option.formattedEnd;div.appendChild(period);
      const price=document.createElement('div');price.className='option-price';price.textContent=formatMoney(option.price);div.appendChild(price);
      if(!option.available){const u=document.createElement('div');u.textContent='Perioden er ikke ledig.';div.appendChild(u);}
    }

    if(option.available)div.addEventListener('click',()=>selectOption(option,div));
    container.appendChild(div);
  });
}

function selectOption(option,element){
  document.querySelectorAll('.booking-option').forEach(el=>el.classList.remove('selected'));
  element.classList.add('selected');
  selectedOption=option;
  hideElement('successCard');

  if(option.custom){
    showElement('customCard');hideElement('formCard');initialiseCustomPeriod();
  }else{
    hideElement('customCard');showElement('formCard');renderPriceSummary();scrollToElement('formCard');
  }
}

function initialiseCustomPeriod(){
  document.getElementById('customStart').value=selectedDate+'T12:00';
  document.getElementById('customEnd').value='';
  document.getElementById('customAvailability').textContent='';
  hideElement('customAvailability');
  scrollToElement('customCard');
}

async function checkCustomAvailability(){
  clearError();
  const startValue=document.getElementById('customStart').value;
  const endValue=document.getElementById('customEnd').value;
  if(!startValue||!endValue)return showError('Vælg både ankomst og afrejse.');
  if(endValue<=startValue)return showError('Afrejse skal være efter ankomst.');

  const button=document.getElementById('customCheckButton');
  button.disabled=true;button.textContent='Kontrollerer...';

  try{
    const result=await api('checkAvailability',{startValue,endValue});
    const box=document.getElementById('customAvailability');
    showElement('customAvailability');
    if(result.available){
      box.textContent='Perioden er umiddelbart ledig. Pris aftales med udlejer.';
      selectedOption={code:'CUSTOM',name:'Anden lejeperiode',custom:true,price:null,start:startValue,end:endValue};
      showElement('formCard');renderPriceSummary();scrollToElement('formCard');
    }else{
      selectedOption={code:'CUSTOM',name:'Anden lejeperiode',custom:true,price:null,start:null,end:null};
      box.textContent='Perioden er desværre ikke ledig.';
      hideElement('formCard');
    }
  }catch(error){showError(error);}
  finally{button.disabled=false;button.textContent='Kontrollér perioden';}
}

function renderPriceSummary(){
  if(!selectedOption||!initialData)return;
  const cleaning=document.getElementById('cleaning').checked;
  const container=document.getElementById('priceSummary');

  if(selectedOption.custom){
    container.innerHTML=`<div class="summary">
      <div class="summary-row"><strong>Lejepris</strong><span>Pris aftales</span></div>
      <div class="summary-row"><span>Depositum</span><span>${formatMoney(initialData.deposit)}</span></div>
      ${cleaning?`<div class="summary-row"><span>Slutrengøring</span><span>${formatMoney(initialData.cleaningPrice)}</span></div>`:''}
      <div class="notice">El er inkluderet op til ${escapeHtml(initialData.includedElectricity)} kWh pr. overnatning.
      Forbrug herudover afregnes med ${formatMoney(initialData.extraElectricityPrice)} pr. kWh.</div>
    </div>`;
    return;
  }

  let total=Number(selectedOption.price)+Number(initialData.deposit);
  if(cleaning)total+=Number(initialData.cleaningPrice);
  container.innerHTML=`<div class="summary">
    <div class="summary-row"><span>Leje</span><span>${formatMoney(selectedOption.price)}</span></div>
    <div class="summary-row"><span>Depositum</span><span>${formatMoney(initialData.deposit)}</span></div>
    ${cleaning?`<div class="summary-row"><span>Slutrengøring</span><span>${formatMoney(initialData.cleaningPrice)}</span></div>`:''}
    <div class="summary-row summary-total"><span>Betales i alt</span><span>${formatMoney(total)}</span></div>
    <div class="notice">El er inkluderet op til ${escapeHtml(initialData.includedElectricity)} kWh pr. overnatning.
    Forbrug herudover afregnes med ${formatMoney(initialData.extraElectricityPrice)} pr. kWh.</div>
  </div>`;
}

async function submitBooking(){
  clearError();
  if(!selectedOption)return showError('Vælg først en lejeperiode.');
  if(selectedOption.custom&&(!selectedOption.start||!selectedOption.end))return showError('Kontrollér først den ønskede specialperiode.');

  const data={
    selectedDate,
    bookingType:selectedOption.code,
    bookingName:selectedOption.name,
    start:selectedOption.start,
    end:selectedOption.end,
    basePrice:selectedOption.price,
    cleaning:document.getElementById('cleaning').checked,
    name:document.getElementById('name').value,
    email:document.getElementById('email').value,
    phone:document.getElementById('phone').value,
    people:document.getElementById('people').value,
    organisation:document.getElementById('organisation').value,
    comment:document.getElementById('comment').value,
    termsAccepted:document.getElementById('terms').checked,
    website:document.getElementById('website').value
  };

  if(!String(data.name).trim())return showError('Navn skal udfyldes.');
  if(!String(data.email).trim())return showError('E-mail skal udfyldes.');
  if(!String(data.phone).trim())return showError('Telefonnummer skal udfyldes.');
  const people=Number(data.people);
  if(!Number.isInteger(people)||people<1)return showError('Antal personer skal være et helt tal større end 0.');
  if(!data.termsAccepted)return showError('Du skal acceptere betingelserne for bookingforespørgslen.');

  const button=document.getElementById('submitButton');
  button.disabled=true;button.textContent='Sender...';

  try{
    const result=await api('submitBooking',{data});
    hideElement('formCard');hideElement('optionsCard');hideElement('customCard');
    const success=document.getElementById('successCard');
    success.innerHTML=`<h2>Tak for din bookingforespørgsel</h2>
      <p>Vi har modtaget din forespørgsel.</p>
      <p>Dit bookingnummer er:</p>
      <p style="font-size:22px"><strong>${escapeHtml(result.bookingId)}</strong></p>
      <p>Bookingen er først gældende, når du har modtaget en bekræftelse fra udlejer.</p>`;
    showElement('successCard');scrollToElement('successCard');
    resetBookingForm();
    await loadCalendar();
  }catch(error){
    button.disabled=false;button.textContent='Send bookingforespørgsel';showError(error);
  }
}

function resetSelection(){
  selectedDate=null;selectedOption=null;
  hideElement('optionsCard');hideElement('customCard');hideElement('formCard');hideElement('successCard');
}

function resetBookingForm(){
  ['name','email','phone','people','organisation','comment','customStart','customEnd','website'].forEach(id=>{
    const el=document.getElementById(id);if(el)el.value='';
  });
  document.getElementById('cleaning').checked=false;
  document.getElementById('terms').checked=false;
  const button=document.getElementById('submitButton');
  button.disabled=false;button.textContent='Send bookingforespørgsel';
  document.getElementById('customAvailability').textContent='';
  hideElement('customAvailability');
  selectedDate=null;selectedOption=null;
}

function parseLocalDate(dateString){
  const p=String(dateString).split('-');
  return new Date(Number(p[0]),Number(p[1])-1,Number(p[2]),12,0,0);
}
function isPastDate(date){
  const today=new Date();today.setHours(0,0,0,0);
  const compare=new Date(date);compare.setHours(0,0,0,0);
  return compare<today;
}
function formatMoney(amount){
  return new Intl.NumberFormat('da-DK',{style:'currency',currency:'DKK',minimumFractionDigits:0}).format(Number(amount));
}
function showElement(id){const el=document.getElementById(id);if(el)el.classList.remove('hidden');}
function hideElement(id){const el=document.getElementById(id);if(el)el.classList.add('hidden');}
function scrollToElement(id){const el=document.getElementById(id);if(el)el.scrollIntoView({behavior:'smooth',block:'start'});}
function showError(error){
  const box=document.getElementById('error');
  box.textContent=error&&error.message?error.message:String(error);
  showElement('error');
  window.scrollTo({top:0,behavior:'smooth'});
}
function clearError(){const box=document.getElementById('error');if(box)box.textContent='';hideElement('error');}
function escapeHtml(text){const div=document.createElement('div');div.textContent=String(text??'');return div.innerHTML;}
